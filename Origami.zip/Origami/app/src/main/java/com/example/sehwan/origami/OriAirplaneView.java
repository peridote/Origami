package com.example.sehwan.origami;

import android.app.Activity;
import android.opengl.GLES20;
import android.os.Bundle;

import java.io.InputStream;

/**
 * Created by Sehwan on 2016-06-10.
 */
public class OriAirplaneView extends OriBasicView {

    public void makeView() {
        orenderer.setProgram(vertexshader, fragmentshader);
        orenderer.getObj(paper);
        orenderer.setState();
        orenderer.makeBuffer();
        orenderer.makeVBO();

    }
}
