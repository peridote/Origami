package com.example.sehwan.origami;

import android.opengl.GLES10;
import android.opengl.GLES20;
import android.opengl.GLES30;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;
import java.util.ArrayList;
import java.util.List;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * Created by Sehwan on 2016-06-04.
 */
public class OriRenderer  {
    private List<Float> vertex;
    private List<Short> indices;
    private FloatBuffer vertexBuf;
    private ShortBuffer indiceBuf;
    float[] irotMat;
    float[] rotMat;
    float[] iMat={
            1.0f, 0, 0, 0,
            0, 1.0f, 0, 0,
            0, 0, 1.0f, 0,
            0, 0, 0, 1.0f
    };
    int[] mVboVertices = new int[1];
    int[] mVboIndices = new int[1];
    OriBasicView view;
    OriCamera ocamera;
    OriShader oshader;
    vec3 axis;
    float degreeHigh = 0;
    float degree = 0;
    public static int V_ATTRIB_POSITION = 0;
    public OriRenderer(OriBasicView s) {
        view = s;
        ocamera = new OriCamera();
        oshader = new OriShader();
        axis = new vec3(1.0f, 0, 0);
        irotMat = new float[16];
    }
    public void onDrawFrame() {
        GLES20.glClear(GLES20.GL_DEPTH_BUFFER_BIT | GLES20.GL_COLOR_BUFFER_BIT);
        getIRotMat(degree);
        setUniform();
        draw();
    }
    public void getIRotMat(float degree) {
        rotMat = oshader.getRotMat(axis, degree);
        for(int i=0;i<16;i++) {
            irotMat[i] = rotMat[i/4]*iMat[(i%4)*4]+rotMat[i/4+4]*iMat[(i%4)*4+1]+rotMat[i/4+8]*iMat[(i%4)*4+2]+rotMat[i/4+12]*iMat[(i%4)*4+3];
        }
    }
    public void setState() {
        GLES20.glFrontFace(GLES20.GL_CCW);
        GLES20.glCullFace(GLES20.GL_BACK);
        GLES20.glEnable(GLES20.GL_CULL_FACE);
        GLES20.glDepthFunc(GLES20.GL_LESS);
        GLES20.glDepthMask(true);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
    }

    public void setProgram(String vertexshader, String fragmentshader) {
        oshader.setProgram(vertexshader, fragmentshader);
    }
    public void makeVBO() {
        GLES20.glGenBuffers(1, mVboVertices, 0);
        vertexBuf.position(0);
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, mVboVertices[0]);
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, vertex.size() * 4, vertexBuf, GLES20.GL_STATIC_DRAW);
        GLES20.glGenBuffers(1, mVboIndices, 0);
        indiceBuf.position(0);
        GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, mVboIndices[0]);
        GLES20.glBufferData(GLES20.GL_ELEMENT_ARRAY_BUFFER, indices.size() * 2, indiceBuf, GLES20.GL_STATIC_DRAW);

        int stride = 4 * 3;
//        int position = GLES20.glGetAttribLocation(view.getProgram(),"position");
        GLES20.glEnableVertexAttribArray(V_ATTRIB_POSITION);
        GLES20.glVertexAttribPointer(V_ATTRIB_POSITION, 3, GLES20.GL_FLOAT, false, stride, 0);
    }
    public void changeRotate(vec3 axis, float degree) {
        this.axis = axis;
        degreeHigh = degree;
    }
    public void changeMat(vec3 axis, float degree) {
        /*rotMat = oshader.getRotMat(axis, degree);
        for(int i = 0; i<vertex.size();i=i+3) {
            vec3 point = new vec3(vertex.get(i), vertex.get(i+1), vertex.get(i+2));
            if(axis.cross(point).z>0) {point = point.matx(rotMat); vertex.set(i,point.x); vertex.set(i+1,point.y); vertex.set(i+2,point.z);}
            else ;
        }
        vertexBuf.clear();
        ByteBuffer bb = ByteBuffer.allocateDirect(vertex.size() * 4);
        bb.order(ByteOrder.nativeOrder());
        vertexBuf = bb.asFloatBuffer();

        for(int i = 0; i<vertex.size();i++)
            vertexBuf.put(vertex.get(i));;
        vertexBuf.position(0);*/
        getIRotMat(degreeHigh);
        iMat = irotMat;
        degreeHigh=0;
    }
    public void makeBuffer() {
        /*rotMat = oshader.getRotMat(axis, degreeHigh);
        for(int i = 0; i<vertex.size();i=i+3) {
            vec3 point = new vec3(vertex.get(i), vertex.get(i+1), vertex.get(i+2));
            if(axis.cross(point).y>0) {point = point.matx(rotMat); vertex.set(i,point.x); vertex.set(i+1,point.y); vertex.set(i+2,point.z);}
            else ;
        }*/
        ByteBuffer bb = ByteBuffer.allocateDirect(vertex.size() * 4);
        bb.order(ByteOrder.nativeOrder());
        vertexBuf = bb.asFloatBuffer();

        for(int i = 0; i<vertex.size();i++)
                vertexBuf.put(vertex.get(i));;

        vertexBuf.position(0);

        ByteBuffer bf = ByteBuffer.allocateDirect(indices.size() * 2);
        bf.order(ByteOrder.nativeOrder());
        indiceBuf = bf.asShortBuffer();
        for(int i = 0; i<indices.size();i++)
            indiceBuf.put(indices.get(i));
        indiceBuf.position(0);
    }
    public void setUniform() {
        float[] worldMat = new float[16];
        Matrix.setIdentityM(worldMat, 0);
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(oshader.getProgram(), "projMat"), 1, false, ocamera.getProjMat(), 0);
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(oshader.getProgram(), "viewMat"), 1, false, ocamera.getViewMat(), 0);
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(oshader.getProgram(), "worldMat"), 1, false, worldMat , 0);
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(oshader.getProgram(), "irotMat"), 1, false, irotMat , 0);
        GLES20.glUniform3f(GLES20.glGetUniformLocation(oshader.getProgram(), "axis"), axis.x, axis.y, axis.z);
        GLES20.glUniform3f(GLES20.glGetUniformLocation(oshader.getProgram(), "compare"), 0, 1.0f, 0);
    }

    public void getObj(InputStream is) {

        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        String str;
        vertex = new ArrayList<>();
        indices = new ArrayList<>();
        try {
            while ((str = br.readLine()) != null) {
                String[] s = str.split(" ");
                switch (s[0]) {
                    case "v":
                        for(int i=1; i<s.length; i++) {
                            if(!s[i].equals(""))
                                vertex.add(Float.parseFloat(s[i]));
                            else ;
                        } break;
                    case "f":
                        for(int i=1; i<s.length; i++) {
                            if(!s[i].equals(""))
                            {s[i]=s[i].split("/")[0];
                                indices.add((short)(Short.parseShort(s[i])-1));}
                            else ;
                        } break;
                    default: break;
                }
            }
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
    public void draw() {
        int a = GLES20.glGetAttribLocation(oshader.getProgram(), "position");
        GLES20.glDrawElements(GLES20.GL_TRIANGLES, indices.size(), GLES20.GL_UNSIGNED_SHORT, 0);
        if(degreeHigh>0&&degree<degreeHigh)
        degree=degree+0.5f;
        else if(degreeHigh<0&&degreeHigh<degree){ degree=degree-0.5f;}
        else if(degreeHigh==0) ;
        else {degree=0; changeMat(axis, degreeHigh);}
    }
}
