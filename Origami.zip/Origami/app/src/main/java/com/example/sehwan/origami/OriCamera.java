package com.example.sehwan.origami;

import android.opengl.Matrix;

/**
 * Created by Sehwan on 2016-06-22.
 */
public class OriCamera {
    vec3 At, Eye, Up;
    float[] vmat, pmat;
    public OriCamera() {
        At = new vec3();
        Eye = new vec3(25.0f, 25.0f, -25.0f);
        Up = new vec3(0,1.0f,0);
        vmat = new float[16];
        pmat = new float[16];
    }
    public float[] getViewMat() {
        Matrix.setLookAtM(vmat, 0, Eye.x, Eye.y, Eye.z,
        At.x, At.y, At.z, Up.x, Up.y, Up.z);
        return vmat;
    }
    public void computeProj(float fovy, int width, int height) {
        Matrix.perspectiveM(pmat, 0, fovy, (float) width/ (float) height, 2.0f, 10000.0f);
    }
    public float[] getProjMat() {
        return pmat;
    }
}
