package com.example.sehwan.origami;

/**
 * Created by Sehwan on 2016-06-22.
 */
public class vec3 {
    public float x,y,z;
    public vec3() {
        x=0; y=0; z=0;
    }
    public vec3(float x, float y, float z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }
    public vec3 normalize() {
        float n = length();
        return new vec3(x/n,y/n,z/n);
    }
    public float length() {
        return x*x + y*y + z*z;
    }
    public vec3 cross(vec3 a) {
        return new vec3(this.y*a.z-this.z*a.y, -this.x*a.z+this.z*a.x, this.x*a.y-this.y*a.x);
    }
    public vec3 matx(float[] mat) {
        return new vec3(mat[0]*x+mat[4]*y+mat[8]*z, mat[1]*x+mat[5]*y+mat[9]*z, mat[2]*x+mat[6]*y+mat[10]*z);
    }
}
