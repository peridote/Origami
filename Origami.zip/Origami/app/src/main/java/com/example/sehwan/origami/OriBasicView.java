package com.example.sehwan.origami;

import android.app.Activity;
import android.opengl.GLES20;
import android.os.Bundle;
import android.view.MotionEvent;

import com.example.sehwan.origami.OriSurfaceView;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

/**
 * Created by Sehwan on 2016-06-21.
 */
public abstract class OriBasicView extends Activity {
    protected OriRenderer orenderer;
    protected String vertexshader;
    protected String fragmentshader;
    protected InputStream paper;
    private GLView glview;
    private OriViewRend glviewren;
    protected int width=0, height=0;
    private InputStream list;
    private ArrayList<vec3> axisList;
    private ArrayList<Float> degreeList;
    private int n = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        glview = new GLView(this);
        glviewren = new OriViewRend(this);
        list = FileLoader.GetStream(this, "list");
        vertexshader = FileLoader.ReadTxtFile(this, "ori.vs");
        fragmentshader = FileLoader.ReadTxtFile(this, "ori.fs");
        paper = FileLoader.GetStream(this, "ori5.obj");
        orenderer = new OriRenderer(this);
        glview.setRenderer(glviewren);
        setContentView(glview);
        getList(list);
    }
    private void getList(InputStream list) {
        axisList = new ArrayList<vec3>();
        degreeList = new ArrayList<>();
        BufferedReader br = new BufferedReader(new InputStreamReader(list));
        String str;
        try {
            while ((str = br.readLine()) != null) {
                String[] s = str.split(" ");
                float[] vec = new float[3];
                for(int i = 0;i<3;i++) {
                    vec[i]=Float.parseFloat(s[i]);
                }
                vec3 axis = new vec3(vec[0],vec[1],vec[2]);
                axisList.add(axis);
                degreeList.add(Float.parseFloat(s[3]));
        }
        } catch (Exception e){e.printStackTrace();}
    }
    public vec3 getAxis() {
        return axisList.get(n);
    }
    public float getDegree() {
        return degreeList.get(n);
    }
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN: return true;
            case MotionEvent.ACTION_UP: if(n<axisList.size()) {
            orenderer.changeRotate(axisList.get(n), degreeList.get(n));
        n++;} break;
            default: break;
        }
        return super.onTouchEvent(event);
    }

    protected void getWH(int width, int height) {
        this.width = width;
        this.height = height;
        orenderer.ocamera.computeProj(60.0f, width, height);
    }
    protected void onDraw() {
        orenderer.onDrawFrame();
    }

    protected abstract void makeView();
}
