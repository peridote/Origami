package com.example.sehwan.origami;

import android.content.Context;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * Created by Sehwan on 2016-06-21.
 */
public class FileLoader {

    private  FileLoader() {

    }

    public static String ReadTxtFile(Context c, String filename)
    {
        return GetString(GetStream(c, filename));
    }

    public static InputStream GetStream(Context c, String filename)
        {
        InputStream is = null;

        try {
            is = c.getAssets().open(filename);

        } catch (IOException e) {
            e.printStackTrace();

        }

        return is;

    }

    public static String GetString(InputStream is) {

        BufferedReader br = null;
        StringBuilder sb = new StringBuilder();

        String line;
        try {

            br = new BufferedReader(new InputStreamReader(is));
            while ((line = br.readLine()) != null) {
                sb.append(line);
                sb.append('\n');
            }

        } catch (IOException e) {
            e.printStackTrace();

        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        }

        return sb.toString();

    }
}
