package com.example.sehwan.origami;

import android.opengl.GLES30;
import android.opengl.GLES30;

/**
 * Created by Sehwan on 2016-06-23.
 */
public class OriShader {
    private int oprogram;
    public OriShader() {
        oprogram = 0;
    }
    int loadShader(int type, String source) {
        int shader = GLES30.glCreateShader(type);
        GLES30.glShaderSource(shader, source);
        GLES30.glCompileShader(shader);
        return shader;
    }
     void setProgram(String vertexshader, String fragmentshader) {
        int vertexShader = loadShader(GLES30.GL_VERTEX_SHADER, vertexshader);
        int fragmentShader = loadShader(GLES30.GL_FRAGMENT_SHADER,fragmentshader);
        oprogram = GLES30.glCreateProgram();
        GLES30.glAttachShader(oprogram, vertexShader);
        GLES30.glAttachShader(oprogram, fragmentShader);
        GLES30.glBindAttribLocation(oprogram, 0, "position");
        GLES30.glLinkProgram(oprogram);
        GLES30.glUseProgram(oprogram);
    }
    public float[] getRotMat(vec3 axis, float degree) {
        axis = axis.normalize();

        float rad = (degree / 180.0f) * 3.141592654f;

        float cos_ = (float)Math.cos(rad);

        float sin_ = (float)Math.sin(rad);

        float x2 = axis.x * axis.x;

        float y2 = axis.y * axis.y;

        float z2 = axis.z * axis.z;

        float oneMinusCos = 1.0f - cos_;

        float[] rotMat =
                {       (oneMinusCos * x2) + cos_, (oneMinusCos * axis.x * axis.y) + (axis.z * sin_), (oneMinusCos * axis.x * axis.z) - (axis.y * sin_), 0,
                        (oneMinusCos * axis.x * axis.y) - (axis.z * sin_), (oneMinusCos * y2) + cos_,  (oneMinusCos * axis.y * axis.z) + (axis.x * sin_), 0,
                        (oneMinusCos * axis.y * axis.z) + (axis.y * sin_), (oneMinusCos * axis.y * axis.z) - (axis.x * sin_),   (oneMinusCos * z2) + cos_ , 0,
                0, 0, 0, 1};
        return rotMat;
    }
    public float[] getRotMat(vec3 axis) {
        return getRotMat(axis, 180.0f);
    }
    public int getProgram() {
        return oprogram;
    }
}
